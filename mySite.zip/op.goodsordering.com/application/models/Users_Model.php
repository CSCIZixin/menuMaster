<?
class Users_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	
	
	public function login($username, $password)
	{
		
		$this->db->select("CusID");
		$this->db->where("userName", $username);
		$this->db->where("password", $password);
		$result = $this->db->get("Customer")->result();
		if(count($result) > 0)
			return true;
		else
			return false;
	}
	
	public function createUser( $fullname,$userName,$phonenum, $email, $address, $Password)
	{
		
		$this->db->set("Cusname", $fullname);
		$this->db->set("Username", $userName);
		$this->db->set("Email", $email);
		$this->db->set("Phone#", $phonenum);
		$this->db->set("Password", $Password);
		//echo $this->db->get_compiled_insert("Users", FALSE)."<br>";
		$this->db->insert("Customer");
		echo "complete";
		//echo $this->db->last_query()."<br>";
		
		//return $this->db->insert_id();
	}
	
	public function getUserID($username)
	{
		$this->db->select("CusID");
		$this->db->where("userName", $username);
		return $this->db->get("Customer")->row()->CusID;//returns first row, single column value
	}
	
	public function getUserInfo($userID)
	{
		$this->db->select("userName");
		$this->db->where("CusID", $userID);
		return $this->db->get("Customer")->row();//returns single row object
	}
	
	public function trackOrder($userID){
		$this->db->select("orderID","Summary");
		$this->db->where("CusID", $userID);
		return $this->db->get("Customer")->row();
		
	}
	
	public function getUserRoles($userID)
	{
		/*
SELECT Users.Username, Users.UserID, Roles.RoleName, Roles.RoleID
FROM Users
JOIN AssignedRoles
	ON Users.UserID = AssignedRoles.UserID
JOIN Roles
	ON AssignedRoles.RoleID = Roles.RoleID
		*/
		$this->db->select("role.roleName, role.roleID");
		$this->db->from("Customer");
		//$this->db->join("AssignedRoles", "Users.UserID = AssignedRoles.UserID");
		$this->db->join("role", "Customer.roleID = role.roleID");
		$this->db->where("Customer.CusID", $userID);
		return $this->db->get()->result();//returns array of row objects
		
	}
	
}

							   

?>
<?class Order_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function makeOrder( $Cusid)
	{
		//$Summary=$meat.$drink.$pref;
		
		$this->db->set("CusID", $Cusid);
	
		
		//echo $this->db->get_compiled_insert("Users", FALSE)."<br>";
		$this->db->insert("Ordertable");
		
		
		$this->db->limit(1);
		$this->db->order_by('OrderID','DESC');
		$query = $this->db->get('Ordertable');
		foreach ( $query->result() as $row)
{
        echo $row->OrderID;
}
		
		
		//echo $this->db->last_query()."<br>";
		
		//return $this->db->insert_id();
	}
	public function makeSingleOrder($CusID,$OrderID,$dishID)
	{
		//$Summary=$meat.$drink.$pref;
		
		
		
		$this->db->set("CusID", $CusID);
		$this->db->set("orderID", $OrderID);
		$this->db->set("DishID", $dishID);
	
		
		//echo $this->db->get_compiled_insert("Users", FALSE)."<br>";
		$this->db->insert("singleOrder");
		echo "insert complete";
		//echo $this->db->last_query()."<br>";
		
		//return $this->db->insert_id();
	}
	
}
?>
<?
class Dish_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function createDish( $Price,$Dishname,$ingredients)
	{
		
		$this->db->set("Price", $Price);
		$this->db->set("Dishname", $Dishname);
		$this->db->set("ingredients", $ingredients);
		
		//echo $this->db->get_compiled_insert("Users", FALSE)."<br>";
		$this->db->insert("Dish");
		echo "complete";
		//echo $this->db->last_query()."<br>";
		
		//return $this->db->insert_id();
	}
	
	function row_delete($id)
{
   $this->db->where('DishID', $id);
   $this->db->delete('testimonials'); 
}
	public function getAllDishes()
	{
		$this->db->select("Price,Dishname,DishID,ingredients");
		$this->db->from("Dish");
		return $this->db->get()->result();
		//json_encode();

	}
	
	public function getAllOrders()
	{
		//"SELECT Dish.Dishname,singleOrder.orderID FROM singleOrder,Dish where Dish.DishID=singleOrder.DishID GROUP BY(singleOrder.orderID)"
		$this->db->select("Dish.Dishname,Dish.ingredients,singleOrder.orderID");
		$this->db->from("singleOrder,Dish");
		$this->db->where("Dish.DishID=singleOrder.DishID");
		$this->db->ORDER_BY('singleOrder.orderID');
		return $this->db->get()->result();
		//json_encode();

	}
	
}

							   




?>
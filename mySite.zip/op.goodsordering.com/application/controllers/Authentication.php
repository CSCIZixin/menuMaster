<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Controller {
	
	private $data;
	private $name;
	private $pass;
	public function __construct()
	{
		parent::__construct();
	}
	
	public function index()
	{
		redirect('/');
	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		$this->load->view("home");
	}
	
	public function loginView(){
		/*$this->data['view'] = "Login";
		$this->data['header'] = "Log In";
		$this->load->view('template', $this->data);*/
		
		$this->load->view('Login');
		
		
	}
	
	public function loadName(){
		
		echo $this->session->userdata("userName");
		
			
	}
	
	
	
	
	public function loadSession(){
		
		echo "You have logged in <br>";
		
		$this->load->view('SessionInfo');
		
		
	}
	
	public function LoadView(){
		echo "<li><a href='#' class = 'home'>Home</a></li>";
		if(in_array(1, $this->session->userdata("RoleIDs")))
		{
		   echo "<li><a href='#' class='menu'> menu</a></li>";
			echo "<li><a href='#'> Track Order</a></li>";
					  
		}	  
		
		
		if(in_array(2, $this->session->userdata("RoleIDs")))
		{
		
			echo "<li><a href='#'> Create a dish</a></li>";
			echo "<li><a href='#'> Delete a dish</a></li>";
			echo "<li><a href='#'> List all dishes a dish</a></li>";
			
		
		}
		 if(in_array(3, $this->session->userdata("RoleIDs")))
		{
			echo "<li><a href='#'> View Order</a></li>";
			
		}
	
	}
	
	
	
	
	
	
	
	public function login()
	{
		/*
		//prevent page from loading if already logged in
		if($this->session->has_userdata("userID") && is_numeric($this->session->userdata("userID")))
		{
			redirect("/");
		}*/
		
		
		$this->name=$_POST["name"];
		$this->pass=$_POST["pass"];
		
		
		
		
		$this->form_validation->set_rules("name", "Username", "required|min_length[3]");
		$this->form_validation->set_rules("pass", "Password", "required|min_length[6]|callback_authenticate");
		if($this->form_validation->run() === FALSE)
			{
		
				echo form_error("name");
				echo form_error("pass");
		}
		
		
		else
			{
				
				//passed all rules
				$this->data['userID'] = $this->Users_Model->getUserID($this->name);
				
				//write some session data for the logged in user
				$this->session->set_userdata("userID", $this->data['userID']);
				
				//returns a row object about the logged in user
				$userInfo = $this->Users_Model->getUserInfo($this->data['userID']);
				$this->session->set_userdata("userName", $userInfo->userName);
				
				
				$roles = $this->Users_Model->getUserRoles($this->data['userID']);
				if(count($roles) > 0)
				{
					foreach($roles as $row)
					{
						$roleIDs[] = $row->roleID;
						$roleNames[] = $row->roleName;
					}
					$this->session->set_userdata("RoleIDs", $roleIDs);
					$this->session->set_userdata("RoleNames", $roleNames);
					
				}
				
				$this->session->set_flashdata("message", "Logged in successfully!");
				//redirect("/");
				
				//$this->data['successMessage'] = "Logged in successfully!";
				//$this->data['view'] = "examples/success";
				
	
			
			
				
			}
		
		
	}
	
	public function authenticate($password)
	{
		$username = $this->name;
		//$password = hash("sha512",$password.$this->config->item('salt'));
		if(!$this->Users_Model->login($username, $password))
		{
			
			$this->form_validation->set_message("authenticate", "Incorrect username or password.");
			return false;
		}
		return true;
	}
	
	public function makeOrder()
	{
		
		$this->load->model("Order_Model");
		$this->Order_Model->makeOrder($_POST['id']);
		
	}
	
	public function makeSingleOrder()
	{
		$this->load->model("Order_Model");
		$this->Order_Model->makeSingleOrder($_POST['CustID'],$_POST['OrderId'],$_POST['DishID']);
		
		
		
	}
	public function getOrder()
	{
		$this->load->model("Dish_Model");
		$data['item'] =$this->Dish_Model->getAllOrders();
		$this->load->view("ViewOrder",$data);	
		
	}
	
	
	
	
	
	public function createUser()
	{
		//prevent page from loading if already logged in
		if($this->session->has_userdata("userID") && is_numeric($this->session->userdata("userID")))
		{
			redirect("/");
		}
		
		//at the top so it can be overriden by successful form submission
		
		//$this->data['view'] = "createUser";
		
		if($this->input->post("MySubmit"))
		{
			
			
		//$fieldName, userFriendlyName, Rules
			$this->form_validation->set_rules("fullname", "Full Name", "required");
			$this->form_validation->set_rules("Password", "Password", "required");
			$this->form_validation->set_rules("userName", "Username", "required|min_length[3]|is_unique[Customer.Cusname]");
			$this->form_validation->set_rules("phonenum", "phonenum", "required|exact_length[10]");
			$this->form_validation->set_rules("Email", "Email", "required|valid_email|is_unique[Customer.Email]");
			
			$this->form_validation->set_rules("Password", "Password", "required|min_length[6]");
			$this->form_validation->set_rules("PasswordConf", "Password Confirmation", "required|matches[Password]");
	
			
			if($this->form_validation->run() === FALSE)
			{
				echo"Try a again";
				//failed a rule
			}
			else
			{
				
				
				//passed all rules
				$this->load->model("Users_Model");
				
			
					$this->Users_Model->createUser(
					$this->input->post("fullname"),
					$this->input->post("userName"),
					$this->input->post("Password"),
					$this->input->post("Email"), 
					$this->input->post("address"), 
					$this->input->post("phonenum")
					
					);
				
				
				//$this->data['successMessage'] = "User account created succesfully!";
				//$this->data['view'] = "examples/success";//change view
				
				
			}
		}
		
		//basic pieces to load a page
		//$this->data['header'] = "Create User";
		$this->load->view("createUser");
		
		//$this->load->view('template', $this->data);
	}
	public function PasswordStrength($password)
	{
		if(is_numeric($password))
		{
			$this->form_validation->set_message("PasswordStrength", "The given password is not strong enough.");
			return false;
		}
		return true;
	}
}

?>
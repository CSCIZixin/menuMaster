<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Toview extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		
		//only roleID 1 is allowed access
		
		
		
		
		
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		
		
	}
	public function menu()
	{
		$this->load->view('menu');
		
	}
	
	
	public function createUser(){
		
		
		
		if($this->input->post("MySubmit"))
		{
		
			//$fieldName, userFriendlyName, Rules
			$this->form_validation->set_rules("fullname", "Full Name", "required");
			$this->form_validation->set_rules("Password", "Password", "required");
			$this->form_validation->set_rules("userName", "Username", "required|min_length[3]|is_unique[Customer.Cusname]");
			$this->form_validation->set_rules("phonenum", "phonenum", "required|exact_length[10]");
			$this->form_validation->set_rules("Email", "Email", "required|valid_email|is_unique[Customer.Email]");
			
			$this->form_validation->set_rules("Password", "Password", "required|min_length[6]");
			$this->form_validation->set_rules("PasswordConf", "Password Confirmation", "required|matches[Password]");
	
			
			if($this->form_validation->run() === FALSE)
			{
				echo"Try a again";
				//failed a rule
			}
			else
			{
				
				
				//passed all rules
				$this->load->model("Users_Model");
				
			
					$this->Users_Model->createUser(
					$this->input->post("fullname"),
					$this->input->post("userName"),
					$this->input->post("Password"),
					$this->input->post("Email"), 
					$this->input->post("address"), 
					$this->input->post("phonenum")
					
					);
				
				
				//$this->data['successMessage'] = "User account created succesfully!";
				//$this->data['view'] = "examples/success";//change view
				
				
			}
		
	}

	$this->load->View('createUser');
	
	
	
	}
	
	public function makeDish(){
		
		
	
		if($this->input->post("mySubmit"))
		{
			
		
			//$fieldName, userFriendlyName, Rules
			$this->form_validation->set_rules("Dishname", "Dish name", "required");
			$this->form_validation->set_rules("ingredients", "Ingredients", "required");
			$this->form_validation->set_rules("Price", "Price", "required|numeric");
	
			
			if($this->form_validation->run() === FALSE)
			{
				echo"Try a again";
				//failed a rule
			}
			else
			{
				
				
				//passed all rules
				$this->load->model("Dish_Model");
				
			
					$this->Dish_Model->createDish(
					$this->input->post("Price"),
					$this->input->post("Dishname"),
					$this->input->post("ingredients")
					
					);
				
				
				//$this->data['successMessage'] = "User account created succesfully!";
				//$this->data['view'] = "examples/success";//change view
				
				
			}
		
	}
	$this->load->View('makeDish');
	
	}
	
	public function makeOrder(){
		
		
	
		if($this->input->post("mySubmit"))
		{
			
		
			//$fieldName, userFriendlyName, Rules
			$this->form_validation->set_rules("meat", "Dish name", "required");
			$this->form_validation->set_rules("drink", "drink", "required");
	
			
			if($this->form_validation->run() === FALSE)
			{
				echo"Try a again";
				//failed a rule
			}
			else
			{
				
				
				//passed all rules
				$this->load->model("Order_Model");
				
			
					$this->Order_Model->makeOrder(
					$this->input->post("drink"),
					$this->input->post("meat"),
					$this->input->post("pref")
					
					);
				
				
				//$this->data['successMessage'] = "User account created succesfully!";
				//$this->data['view'] = "examples/success";//change view
				
				
			}
		
	}
	$this->load->View('makeOrder');
	
	
	
	}
	
	public function home(){
		
		$this->load->view("home");
		
	}
	
	
	
	
	
	public function ViewOrder(){
		$this->load->view("ViewOrder");
		
		
		
	}
	
	
	public function trackOrder(){
		$this->load->view("ViewOrder");
		
		
		
	}
	public function deleteDish(){
		$this->load->view("deleteDish");
		
		
		
	}
	
	public function viewDishes(){
		$data["item"] =$this->Dish_Model->getAllDishes();
		$this->load->view("ViewDish",$data);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

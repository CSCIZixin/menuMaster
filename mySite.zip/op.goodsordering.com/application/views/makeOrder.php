<?
// This file is in /application/views/examples/createUser.php

echo form_open('');//produces <form>
echo "<table class='form'>";


$options = array(
        'Beef'         => 'Beef',
        'Chicken'         => 'Chicken',
        'Fish'         => 'Fish',
        'Pork'        => 'Pork',
		
);
echo "<tr class='".((strlen(form_error('fullname'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Select you meat", "Dishname");
	echo "</td>";
	echo "<td>";
echo form_dropdown("meat",$options);
	echo "</td>";
	echo "<td>";
echo form_error('meat');
	echo "</td>";


echo "<tr class='".((strlen(form_error('fullname'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Select you drink: ", "Dishname");
	echo "</td>";
	echo "<td>";
echo "Water".form_radio("drink", "Water");
	echo "</td>";
echo "<td>";
echo "Coke".form_radio("drink", "Coke");
	echo "</td>";
echo "<td>";
echo "Iced tea".form_radio("drink", "Iced tea");
	echo "</td>";
	echo "<td>";
echo form_error('drink');
	echo "</td>";

echo "</table>";

echo "</tr>";

$options = array(
	'name' => 'pref',
	'id' => 'pref',
	'rows' => 5,
	'cols' => 50,
	'value' => set_value('pref'),
);
echo "<tr class='".((strlen(form_error('fullname'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label(" Any preference?(*Optional)", "ingredients");
	echo "</td>";
	echo "<td>";
echo form_textarea($options);
	echo "</td>";
	echo "<td>";
echo form_error('pref');
	echo "</td>";

echo "</tr>";


echo"<br>";

echo form_submit("mySubmit", "Order");

echo form_close();//produces </form>
?>

<li><a href="<?php echo site_url("Welcome"); ?>">Home</a></li>



<!DOCTYPE html>
<html>
<body>

<div id='showCD'></div><br>
<input type="button" id = "prev" value="<<">
<input type="button"  value=">>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

	
	
	$(document).ready(function(){
		var arr;
		
		$.ajax({url: "<?= site_url("AJAX/getItem"); ?>", 
				method: "POST",
				success: function(result){
					alert (result);
        }});
		
    $("input#prev").on("click",function(){
		alert("kkk");
		var text = arr['Dishname'];
		$("#showCD").html(text);
        
    });
});
	
	
	
	
/*		

function next() {
if (i < len-1) {
  i++;
  displayCD(i);
  }
}

function previous() {
if (i > 0) {
  i--;
  displayCD(i);
  }
}

/*
	
</script>

	
	
	



</body>
</html>

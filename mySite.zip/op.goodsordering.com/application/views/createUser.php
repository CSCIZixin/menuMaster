<script>



</script>




<?
// This file is in /application/views/examples/createUser.php

echo form_open();//produces <form>
echo "<table class='form'>";
$options = array(
	'name' => 'fullname',
	'id' => 'fullname',
	'value' => set_value('fullname'),
);
echo "<tr class='".((strlen(form_error('fullname'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Full name", "Full Name");
	echo "</td>";
	echo "<td>";
echo form_input($options);
	echo "</td>";
	echo "<td>";
echo form_error('fullname');
	echo "</td>";

echo "</tr>";

$options['name'] = 'userName';
$options['id'] = 'userName';
$options['value'] = set_value('userName');
echo "<tr class='".((strlen(form_error('userName'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("User Name", "User Name");
	echo "</td>";
	echo "<td>";
echo form_input($options);
	echo "</td>";
	echo "<td>";
echo form_error('userName');
	echo "</td>";
echo "</tr>";

$options['name'] = 'Email';
$options['id'] = 'Email';
$options['value'] = set_value('Email');
echo "<tr class='".((strlen(form_error('Email'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Email", "Email");
	echo "</td>";
	echo "<td>";
echo form_input($options);
	echo "</td>";
	echo "<td>";
echo form_error('Email');
	echo "</td>";
	
echo "</tr>";

echo "</tr>";

$options['name'] = 'phonenum';
$options['id'] = 'phonenum';
$options['value'] = set_value('phonenum');
echo "<tr class='".((strlen(form_error('phonenum'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("phone#", "phonenum");
	echo "</td>";
	echo "<td>";
echo form_input($options);
	echo "</td>";
	echo "<td>";
echo form_error('phonenum');
	echo "</td>";
	
echo "</tr>";

$options = array(
	'name' => 'Summary',
	'id' => 'Summary',
	'rows' => 5,
	'cols' => 50,
	'value' => set_value("Summary"),
);
echo "<tr class='".((strlen(form_error('Summary'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Address(*optional)", "Summary");
	echo "</td>";
	echo "<td>";
echo form_textarea($options);
	echo "</td>";
echo "</tr>";



echo "<tr class='".((strlen(form_error('Password'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Password", "Password");
	echo "</td>";
	echo "<td>";
echo form_password("Password", "", array('id'=>'Password'));
	echo "</td>";
	echo "<td>";
echo form_error('Password');
	echo "</td>";
echo "</tr>";

echo "<tr class='".((strlen(form_error('PasswordConf'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Password Confirmation", "PasswordConf");
	echo "</td>";
	echo "<td>";
echo form_password("PasswordConf", "", array('id'=>'PasswordConf'));
	echo "</td>";
	echo "<td>";
echo form_error('PasswordConf');
	echo "</td>";
echo "</tr>";
echo "</table>";

echo form_submit("MySubmit", "Register User");

echo form_close();//produces </form>



?>

<li><a href="<?php echo site_url("Welcome"); ?>">Home</a></li>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    /* Remove the jumbotron's default bottom margin */ 
     .jumbotron {
      margin-bottom: 0;
    }
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>
<body>
	<script>
	$(document).ready(function(){
		$(".dish").on("click",function(){
			$.ajax({
				url: "<?= site_url("Toview/ViewDishes"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				$(".content").html(data);
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
	});
		
		
		$(document).ready(function(){
		$(".home").on("click",function(){
			$.ajax({
				url: "<?= site_url("Toview/home"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				$(".content").html(data);
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
	});
				
				
		$(document).ready(function(){
		$(".MakeOrder").on("click",function(){
			$.ajax({
				url: "<?= site_url("Toview/makeOrder"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				$(".content").html(data);
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
	});
		$(document).ready(function(){
		$(".login").on("click",function(){
			$.ajax({
				url: "<?= site_url("Authentication/loginView"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				$(".content").html(data);
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
	});
		$(document).ready(function(){
		$(".info").on("click",function(){
			$.ajax({
				url: "<?= site_url("Authentication/loadSession"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				$(".content").html(data);
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
	});
			
		$(document).ready(function(){
		$(".logout").on("click",function(){
			$.ajax({
				url: "<?= site_url("Authentication/logout"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				alert("You have logged out");
				$("#nav").html("<li><a href='#' class = 'home'> Home</a></li>");
				$(".content").html(data);
				$(".login").html("<span class='glyphicon glyphicon-user'></span>Login");
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
	});
		
		$(document).ready(function(){
		$(".menu").on("click",function(){
			$.ajax({
				url: "<?= site_url("Toview/ViewDishes"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				alert("complete");
				$(".content").html(data);
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
	});
		
		
		$(document).ready(function(){
		$(".trackOrder").on("click",function(){
			$.ajax({
				url: "<?= site_url("Authentication/getOrder"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				alert("complete");
				$(".content").html(data);
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
		});
			
			
	});
		
		
		
	</script>
	
<div class="jumbotron">
  <div class="container text-center">
    <h1>Jim's Restaurant</h1>      
    <p>Mission, Vission & Values</p>
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" id="nav">
		  <li><a href='#' class = "home"> Home</a></li>
		  
		  <? 
		  
		  
		  if(!($this->session->has_userdata("userID") && is_numeric($this->session->userdata("userID"))))
		{ 
		   
		}
		  else {
			  if(in_array(1, $this->session->userdata("RoleIDs")))
		{
		    echo "<li><a href='#' class='menu'> menu</a></li>";
			echo "<li><a href='#' class='trackOrder'> Track Order</a></li>";
					  
		}	  
			  
			if(in_array(2, $this->session->userdata("RoleIDs")))
		{
		
			echo "<li><a href='#'> Create a dish</a></li>";
			echo "<li><a href='#'> Delete a dish</a></li>";
			echo "<li><a href='#'> List all dishes</a></li>";
		}
			  
			  if(in_array(3, $this->session->userdata("RoleIDs")))
		{
			echo "<li><a href='#' class='trackOrder'> View Order</a></li>";
			
		}
		  
		  }
		  ?>
		  
      </ul>
      <ul class="nav navbar-nav navbar-right">
		  <?
		   if(!($this->session->has_userdata("userID") && is_numeric($this->session->userdata("userID"))))
		   {
			  echo "<li><a href='#'' class='login'><span class='glyphicon glyphicon-user'></span>Login</a></li>";
			   
		   }
		  else {
			  
			  
			  
			  echo "<li><a href='#'' class='login'><span class='glyphicon glyphicon-user'></span>".$this->session->userdata("userName")."</a></li>";
			  
		  }
		  
		  
		  ?>
		 
		  
        
        
		<li><a href="#"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
		<li><a href="#" class="logout"><span class="glyphicon glyphicon-eye-close"></span> Log out</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container">   
	<div class = "content">
		<? $this->load->view("home");
		
		?>
		</div>
	</div>
		

<footer class="container-fluid text-center">
  <p>Online Store Copyright</p>  
  <form class="form-inline">Get deals:
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Sign Up</button>
  </form>
</footer>
	

</body>
</html>
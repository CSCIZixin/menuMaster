<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<h1>Coming soon</h1>
		
	<li><a href="<?php echo site_url("Welcome"); ?>">Home</a></li>
		
</body>
</html>
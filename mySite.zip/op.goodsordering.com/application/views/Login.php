<!DOCTYPE html>

<script>
$(document).ready(function(){
		$(".submit").on("click",function(){
			$.ajax({
				url: "<?= site_url("Authentication/login");?>",
				data: {
				name: $("#email").val(),
				pass:$("#pwd").val(),
					
				},
				datatype: "json",
				method: "post",
				success: null,
				
			}).done(function(msg1) {
				
				if(msg1)
				$(".msg").html(msg1);
				else{
					
			$.ajax({
				url: "<?= site_url("Authentication/loadName");?>",
				data: null,
				datatype: "json",
				method: "post",
				success: null,
				
			}).done(function(msg) {
				alert(msg);
				$(".login").html( "<span class='glyphicon glyphicon-user' id='gly'></span>"+msg);
			
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});		
					
				
			$.ajax({
				url: "<?= site_url("Authentication/LoadView");?>",
				data: null,
				datatype: "json",
				method: "post",
				success: null,
				
			}).done(function(msg) {
			
				$("#nav").html(msg);
			
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});	
					
			$.ajax({
				url: "<?= site_url("Authentication/loadSession");?>",
				data: null,
				datatype: "json",
				method: "post",
				success: null,
				
			}).done(function(msg) {
			
				$(".content").html(msg);
			
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});	
					
		
				
				}
					
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
			
			
			
			
			
		});
	
	$(".createUser").on("click",function(){
			
			$.ajax({
				url: "<?= site_url("Authentication/createUser"); ?>",
				data: null,
				datatype: "json",
				method: "GET",
				success: null,
				
			}).done(function(data) {
				$(".content").html(data);
				
			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data")
		});
			
		});
	
	
	});	


</script>




<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Horizontal form</h2>
	
	<form class="form-horizontal" >
			
    <div class="form-group">

      <div class="col-sm-10">
		  <p class ="msg">
		  </p>
      </div>
    </div>
		
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Username:</label>
      <div class="col-sm-10">
        <input class="form-control Username" id="email" placeholder="Enter email" name="Username">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Password:</label>
      <div class="col-sm-10">          
        <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <div class="checkbox">
          <label><input type="checkbox" name="remember"> Remember me</label>
        </div>
      </div>
    </div>
		</form>
		
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
		 <button  class="submit">Submit</button>
      </div>
    </div>
	
	<div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
		 <a href="#" class="createUser">Create User</a>
      </div>
    </div>
	
  
	
	
</div>

</body>
</html>

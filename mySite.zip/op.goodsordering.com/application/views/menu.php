<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<ul>
<?
	//logged in user
	if($this->session->has_userdata("userID") && is_numeric($this->session->userdata("userID")))
	{
	?>
		<?
		if($header!="Home"){
		
		?>
	<li><a href="<?php echo site_url("welcome"); ?>">Home</a></li>
		<?
		}
		?>
	
	<?
		//admin menu
		if(in_array(1, $this->session->userdata("RoleIDs")))
		{
		?>
			<li><a href="<?php echo site_url("ToView/makeOrder"); ?>">Make order</a></li>
			<li><a href="<?php echo site_url("ToView/trackOrder"); ?>">Track order</a></li>
		<?
		}
		if(in_array(2, $this->session->userdata("RoleIDs")))
		{
		?>
			<li><a href="<?php echo site_url("ToView/makeDish"); ?>"> Create a dish</a></li>
			<li><a href="<?php echo site_url("ToView/deleteDish"); ?>">Delete a dish </a></li>
			<li><a href="<?php echo site_url("ToView/viewDishes"); ?>">List all dishes </a></li>
		<?
		}
		
		if(in_array(3, $this->session->userdata("RoleIDs")))
		{
		?>
			<li><a href="<?php echo site_url("ToView/ViewOrder"); ?>">ViewOrder</a></li>
			
		<?
		}
		
		
		
		
		
		
		
		
	?>	
	<li><a href="<?php echo site_url("authentication/logout"); ?>">Log Out</a></li>
	<?
	}
	else
	{
	?>
	 	<?
		if($header!="Create User"){
		?>
	<li><a href="<?php echo site_url("authentication/createUser"); ?>">Create User</a></li>
		
		<?
		}
		?>
	<?
		
		
			
	}
?>
</ul>
</body>
</html>
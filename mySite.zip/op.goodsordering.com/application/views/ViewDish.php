<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	
<script>

	$(document).ready(function(){
		
		$("#confirm").on("click",function(){
			var id;
			var val;
			$(".box").each(function(){
				if($(this).prop("checked")==true){
					
					$.ajax({
				url: "<?= site_url("Authentication/makeOrder"); ?>",
				data: {
					id: <? echo $this->session->userdata("userID"); ?> ,	
				},
				datatype: "json",
				method: "POST",
				success: null,
				
			}).done(function(data) {
				id= data;	
				alert(id);
				$(".box").each(function(){
				val=$(this).val();
				if($(this).prop("checked")==true){
				$.ajax({
				url: "<?= site_url("Authentication/makeSingleOrder"); ?>",
				data: {
					DishID: val,
					OrderId: id,
					CustID:<? echo $this->session->userdata("userID"); ?>,
					
				},
				datatype: "json",
				method: "POST",
				success: null,
				
			}).done(function(data) {
				alert(data);
				
		
			}).fail(function() {
				alert("error");
						
				//$("div#messages").html("Failed to submit data");
			});
						
			}
								
				});	
						

			}).fail(function() {
				alert( "error" );
				//$("div#messages").html("Failed to submit data");
			});
					return false;
					
				}	
			});

				
				
			
			
			
		});
	});
	
	
	</script>
	
  <table class="table">
    <thead>
      <tr>
        <th>Dish name</th>
        <th>Price</th>
        <th>Ingredients</th>
      </tr>
    </thead>
    <tbody>
     <?
		
		foreach($item as $row){
		echo '<tr>';
		echo '<th>'.$row->Dishname.'</th>';
		echo '<th>'."$".$row->Price.'</th>';
		echo '<th>'.$row->ingredients.'</th>';
		echo '<th><input type="checkbox" class = "box" value='.$row->DishID.'></th>';
		echo '<tr>';			
		}
		
		?>
		
		
    </tbody>
  </table>
<button type="button" class="btn btn-danger text-center" id="confirm">confirm</button>
</body>
</html>

<?
	echo "User: ";
   if($this->session->has_userdata("userID"))
	echo $this->session->userdata("userName");
	echo "<br>";
	if($this->session->has_userdata("RoleNames"))
	{
		echo "Permissions:<ul>";
		foreach($this->session->userdata("RoleNames") as $roleName)
		{
			echo "<li>".$roleName."</l1>";
		}
		echo "</ul>";
	}

	else{
		echo "Permissions:<ul>";
		echo "<li> Not logged in</l1>";
		echo "</ul>";
	}
	
	//echo $this->session->flashdata("message");
	if($this->session->flashdata("message"))
	{
		echo "<div class='message'>".$this->session->flashdata("message")."</div>";
	}
	?>
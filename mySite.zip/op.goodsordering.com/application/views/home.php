<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<style>
	
	
	
	</style>
	
	
</head>
<div class="container">    
  <div class="row">
    <div class="col-sm-4 col-xs-12 col-md-4">
      <div class="panel panel-primary">
        <div class="panel-heading">BLACK FRIDAY DEAL</div>
        <div class="panel-body"><img src="images/1.jpg"  height="150" width="150" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">Buy one get one free</div>
      </div>
    </div>
    <div class="col-sm-4 col-xs-12 col-md-4" > 
      <div class="panel panel-primary">
        <div class="panel-heading">BLACK FRIDAY DEAL</div>
        <div class="panel-body"><img src="images/2.jpg" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">Buy one get one free</div>
      </div>
    </div>
    <div class="col-sm-4 col-xs-12 col-md-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">BLACK FRIDAY DEAL</div>
        <div class="panel-body"><img src="images/3.jpg" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer">Buy one get one free</div>
      </div>
    </div>
  </div>
</div><br><br>
<body>
</body>
</html>
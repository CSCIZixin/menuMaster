<!doctype html>
<html>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}

	
</style>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	
<div class=“mainContent”>
<h1>Welcome<h1>
<h2> <? echo $header  ?></h2>
	<?
	$this->load->view("SessionInfo");
	?>
<div class=“content”><?php $this->load->view($view); ?></div>
	
		
<div class=“menu”><?php $this->load->view("menu")?></div>

	


	<?
	/*
echo "<br>";
echo "<table style='width:65%'>";
echo  "<tr>";
echo  "   <th>Name</th>";
echo  "   <th>Id</th>";
echo	"<th>email</th>";
echo	"<th>password</th>";
echo	"<th>roleID</th>";
echo  "</tr>";
	
	
	
	
	foreach ($user as $row)
{
	echo "<tr>";	
    echo "<td>".$row->userName."</td>";
	echo "<td>".$row->userID."</td>";
	echo "<td>".$row->email."</td>";
	echo "<td>".$row->password."</td>";
	echo "<td>".$row->roleID."</td>";
	echo "<td>".form_checkbox($row->userName, $row->password, FALSE, $row->roleID)."</td>";
	echo "</tr>";
	
	
	}
	
	
	*/
	
	
?>
	

</div>
	 
</body>
</html>
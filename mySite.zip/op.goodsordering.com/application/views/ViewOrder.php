<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
	
	
	<table class="table">
    <thead>
      <tr>
		<th>Order ID</th>
        <th>Dish name</th>
       
        <th>Ingredients</th>
      </tr>
    </thead>
    <tbody>
     <?
		
		foreach($item as $row){
		
		echo '<th>'.$row->orderID.'</th>';
		echo '<th>'.$row->Dishname.'</th>';
		echo '<th>'.$row->ingredients.'</th>';
		
		echo '<tr>';			
		}
		
		?>
		
		
    </tbody>
  </table>
		
</body>
</html>
<?
// This file is in /application/views/examples/createUser.php

echo form_open('');//produces <form>
echo "<table class='form'>";


$options = array(
	'name' => 'Dishname',
	'id' => 'Dishname',
	'value' => set_value('Dishname'),
);
echo "<tr class='".((strlen(form_error('fullname'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Dish Name", "Dishname");
	echo "</td>";
	echo "<td>";
echo form_input($options);
	echo "</td>";
	echo "<td>";
echo form_error('Dishname');
	echo "</td>";

echo "</tr>";

$options = array(
	'name' => 'ingredients',
	'id' => 'ingredients',
	'rows' => 5,
	'cols' => 50,
	'value' => set_value('ingredients'),
);
echo "<tr class='".((strlen(form_error('fullname'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("ingredients", "ingredients");
	echo "</td>";
	echo "<td>";
echo form_textarea($options);
	echo "</td>";
	echo "<td>";
echo form_error('ingredients');
	echo "</td>";

echo "</tr>";

$options = array(
	'name' => 'Price',
	'id' => 'Price',
	'value' => set_value('Price'),
);
echo "<tr class='".((strlen(form_error('fullname'))>0)?"fieldError":"")."'>";
	echo "<td>";
echo form_label("Price $", "Price");
	echo "</td>";
	echo "<td>";
echo form_input($options);
	echo "</td>";
	echo "<td>";
echo form_error('Price');
	echo "</td>";

echo "</tr>";


echo "</table>";

echo form_submit("mySubmit", "Create");

echo form_close();//produces </form>
?>
<li><a href="<?php echo site_url("Welcome"); ?>">Home</a></li>